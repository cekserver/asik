# Telegram Puzzle Bot — 5000 TXT

Bot Telegram untuk event pencarian file.

## Fitur
- 5000 file TXT bernomor 0001 sampai 5000.
- `/file <nomor>` mengirim file yang dipilih.
- `/start` dan `/help`.
- Token bot dibaca dari environment variable `BOT_TOKEN`.
- Isi file kemenangan tidak dimasukkan ke kode bot.

## Instalasi

### 1. Buat bot
Buat bot melalui BotFather dan ambil tokennya.

### 2. Install dependency

```bash
python3 -m pip install -r requirements.txt
```

### 3. Atur token

Linux/Termux:
```bash
export BOT_TOKEN="TOKEN_BOT_KAMU"
```

Windows CMD:
```cmd
set BOT_TOKEN=TOKEN_BOT_KAMU
```

PowerShell:
```powershell
$env:BOT_TOKEN="TOKEN_BOT_KAMU"
```

### 4. Jalankan

```bash
python3 bot.py
```

Atau Linux/Termux:
```bash
chmod +x run.sh
./run.sh
```

Windows:
```bat
run.bat
```

## Cara pemain
Kirim:

`/file 3830`

Bot akan mengirim file TXT nomor tersebut.

Nomor file hanya menerima 1-5000.

## Catatan keamanan
Jangan pernah meng-upload `BOT_TOKEN` ke GitHub atau membagikannya.

Bot mengirim file langsung dari folder `files/`, sehingga isi file rahasia tidak perlu berada di source code `bot.py`.
