from pathlib import Path
import secrets

FILES_DIR = Path(__file__).resolve().parent / "files"
WINNING_FILE = 3928
TOTAL = 5000

FILES_DIR.mkdir(exist_ok=True)

for i in range(1, TOTAL + 1):
    path = FILES_DIR / f"{i:04d}.txt"

    if i == WINNING_FILE:
        content = "YOU WINNER"
    else:
        content = (
            f"FILE {i:04d}\n\n"
            "Tidak ada apa-apa di sini.\n"
            f"Kode: {secrets.token_hex(8)}"
        )

    path.write_text(content, encoding="utf-8")

print(f"Selesai membuat {TOTAL} file.")
