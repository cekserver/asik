@echo off
if "%BOT_TOKEN%"=="" (
    echo BOT_TOKEN belum diatur.
    echo Set BOT_TOKEN terlebih dahulu.
    exit /b 1
)

py -m pip install -r requirements.txt
py bot.py
