#!/bin/sh
set -e

if [ -z "$BOT_TOKEN" ]; then
  echo "BOT_TOKEN belum diatur."
  echo "Contoh: export BOT_TOKEN='TOKEN_BOT_KAMU'"
  exit 1
fi

python3 -m pip install -r requirements.txt
python3 bot.py
