import os
import logging
from pathlib import Path

from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    ContextTypes,
)

TOKEN = os.getenv("BOT_TOKEN")
FILES_DIR = Path(__file__).resolve().parent / "files"
MAX_FILE = 5000

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🗂️ FILE HUNT\n\n"
        "Ada 5000 file TXT.\n"
        "Pilih nomor file dan gunakan:\n"
        "/file <nomor>\n\n"
        "Contoh:\n"
        "/file 3830\n\n"
        "Cari file yang tepat. Good luck."
    )


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Perintah:\n"
        "/start - mulai event\n"
        "/file <nomor> - mengambil file TXT\n"
        "/help - bantuan\n\n"
        "Nomor file: 1 sampai 5000."
    )


async def get_file(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text(
            "Format salah.\nGunakan: /file <nomor>\nContoh: /file 3830"
        )
        return

    if len(context.args) != 1 or not context.args[0].isdigit():
        await update.message.reply_text("Nomor file harus berupa angka 1-5000.")
        return

    number = int(context.args[0])

    if number < 1 or number > MAX_FILE:
        await update.message.reply_text("Nomor file harus antara 1 dan 5000.")
        return

    path = FILES_DIR / f"{number:04d}.txt"

    if not path.is_file():
        await update.message.reply_text("File tidak ditemukan.")
        return

    try:
        with path.open("rb") as f:
            await update.message.reply_document(
                document=f,
                filename=path.name,
                caption=f"📄 File #{number:04d}",
            )
    except Exception:
        logger.exception("Gagal mengirim file %s", number)
        await update.message.reply_text("Gagal mengirim file. Coba lagi.")


def main():
    if not TOKEN:
        raise RuntimeError(
            "BOT_TOKEN belum diatur. "
            "Set environment variable BOT_TOKEN dengan token bot Telegram."
        )

    if not FILES_DIR.exists():
        raise RuntimeError("Folder files/ tidak ditemukan.")

    app = Application.builder().token(TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("file", get_file))

    logger.info("Bot berjalan...")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
